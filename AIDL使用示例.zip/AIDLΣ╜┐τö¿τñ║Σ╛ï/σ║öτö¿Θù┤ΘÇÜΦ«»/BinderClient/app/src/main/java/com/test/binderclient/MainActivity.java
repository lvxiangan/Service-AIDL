package com.test.binderclient;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.test.binderserver.aidl.ITest;

public class MainActivity extends AppCompatActivity {
    ITest iTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 获取服务端的Service
        findViewById(R.id.bindBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Google推荐方法，支持5.0以上系统
                Intent intent = new Intent();
                intent.setAction("com.test.binderserver.MY_SERVICE");// 设置服务器app 中 MyService的action
                intent.setPackage("com.test.binderserver");          // 设置服务器app 的包名
                bindService(intent, connection, Context.BIND_AUTO_CREATE);
            }
        });
        // 调用服务端的Service方法
        findViewById(R.id.readBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int result = iTest.add(3, 4);
                    System.out.println("得到跨进程结果---->" + result);

                    iTest.printStr("hello 来自客户端");

                } catch (Exception e) { }
            }
        });
    }

    // 创建服务连接器
    ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 当连接上后，找到服务端返回的对象
            iTest = ITest.Stub.asInterface(service);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };
}
