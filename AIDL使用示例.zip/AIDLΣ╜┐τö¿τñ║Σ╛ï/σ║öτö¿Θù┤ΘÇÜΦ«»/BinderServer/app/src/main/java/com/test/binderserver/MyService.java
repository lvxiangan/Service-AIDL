package com.test.binderserver;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.test.binderserver.aidl.ITest;

public class MyService extends Service {


    @Override
    public IBinder onBind(Intent intent) {
        // 3、把Stub的实现类，作为返回值返回
        return mBinder;
    }


    // 1、Stub抽象类在重新编译 aidl 文件产生
    ITest.Stub mBinder = new ITest.Stub() {

        // 2、实现ITest定义的所有方法，下同。
        @Override
        public int add(int a, int b) throws RemoteException {
            return a + b;
        }

        @Override
        public void printStr(String str) throws RemoteException {
            System.out.println("---------打印结果------->" + str);
        }
    };


}
