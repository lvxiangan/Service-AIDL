package com.test.bindertest;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

public class MyService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }


    ITest.Stub mBinder = new ITest.Stub() {
        @Override
        public int add(int a, int b) throws RemoteException {
            return a + b;
        }

        @Override
        public void printStr(String str) throws RemoteException {
            System.err.println("----来自服务进程的打印--->" + str);

            System.err.println("获取static变量----->" + MainActivity.MY_TAG);

        }
    };


}
