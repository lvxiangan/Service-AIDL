package com.test.bindertest;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {


    public static String MY_TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ServiceConnection connection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                ITest iTest = ITest.Stub.asInterface(service);
                try {
                    int result = iTest.add(2, 3);
                    System.err.println("相加结果--->" + result);

                    iTest.printStr("hello world!");

                } catch (Exception e) {}
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };

        // Google推荐方法，支持5.0以上系统
        Intent intent = new Intent();
        intent.setAction("com.test.myservice.MY_ACTION");// 设置服务器app 中 MyService的action
        intent.setPackage("com.test.bindertest");          // 设置服务器app 的包名
        bindService(intent, connection, Context.BIND_AUTO_CREATE);

    }



}
